/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.servlets;

import com.rentalplus.actions.PropertyAction;
import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.getParameterMap;
import com.rentalplus.common.IsBean;
import com.rentalplus.pojo.PropertyPOJO;
import java.io.IOException;
import java.util.HashMap;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Riddhi
 */
public class SearchServlet extends BaseServlet {

    private PropertyAction propAction;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config); 
        propAction = new PropertyAction();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.doPost(request, response);
        HashMap<String, String> params = getParameterMap(request);
        PropertyPOJO pojo = new PropertyPOJO();
        populate(pojo, params);
        propAction.setBean(pojo);
        propAction.getRowsByBean();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.doGet(request, response); 
    }

    private void populate(IsBean bean, HashMap<String, String> params) {
        PropertyPOJO pojo = CommonUtil.getPropertyPOJO(bean);
        pojo.setPropertyType(params.get("propertyType"));
        pojo.setFurniture(params.get("furniture"));
        pojo.setNoOfBedRoomsString(params.get("noOfBedRooms"));
        pojo.setMinRentString(params.get("minRent"));
        pojo.setMaxRentString(params.get("maxRent"));
        pojo.setTransportationType(params.get("transportationType"));
        pojo.setMinMinutesString(params.get("minMinutes"));
        pojo.setMaxMinutesString(params.get("maxMinutes"));
    }
}
