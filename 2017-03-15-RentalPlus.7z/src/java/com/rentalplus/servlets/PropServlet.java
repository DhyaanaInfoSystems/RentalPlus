/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.servlets;

import com.rentalplus.actions.CityAction;
import com.rentalplus.actions.PropertyAction;
import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.getParametersFromMultipartContentRequest;
import static com.rentalplus.common.Constant.ADD;
import static com.rentalplus.common.Constant.MODIFY;
import static com.rentalplus.common.Constant.REMOVE;
import com.rentalplus.common.IsBean;
import com.rentalplus.pojo.PropertyPOJO;
import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author Riddhi
 */
public class PropServlet extends BaseServlet {

    private PropertyAction propAction;
    private CityAction cityAction;
    private String directory;
    private int lastPathIndex;

    @Override
    protected void pathComponents(String url) {
        this.requestUri = url;
        // out.println(requestUri);
        pathElements = requestUri.split("/");
//        out.print(Arrays.toString(pathElements));
        directory = pathElements[1];
        base = pathElements[2];
        actionHandler = pathElements[3];
        action = pathElements[4];
        id = "0";
        lastPathIndex = 4;
        if (pathElements.length > 5) {
            id = pathElements[5];
            lastPathIndex++;
        }
    }
    
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        propAction = new PropertyAction();
        cityAction = new CityAction();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        super.doGet(request, response);
        String uri = getServletContext().getInitParameter("base");
        if (REMOVE.equals(action)) {
            String ids = id;
            if (pathElements.length > 5) {
                for (int i = lastPathIndex; i < pathElements.length; i++) {
                    ids += "," + pathElements[i];
                }
            }
            propAction.removeRows(ids);
            session.setAttribute(propAction.getMessageType(), bundle.getString(propAction.getMessage()));
            uri += "admin/properties.jsp";
        } else {
            uri += "admin/property.jsp";
            uri += "?action=" + action + "&id=" + id;
            uri = response.encodeRedirectURL(uri);
        }
        response.sendRedirect(uri);
        out.flush();
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        super.doPost(request, response);
        String uri = getServletContext().getInitParameter("base");
//        if (pathElements.length > 5) {
//            id = pathElements[5];
//        }
        HashMap<String, String> params;
        if (ServletFileUpload.isMultipartContent(request)) {
            params = getParametersFromMultipartContentRequest(request);
        } else {
            params = new HashMap<String, String>();
            Enumeration<String> en = request.getParameterNames();
            while (en.hasMoreElements()) {
                String pkey = en.nextElement();
                String pval;
                String[] values = request.getParameterValues(pkey);
                if (values == null || values.length < 2) {
                    pval = values[0];
                } else {
                    pval = Arrays.toString(values);
                }
                params.put(pkey, pval);
            }
        }
        PropertyPOJO pojo = new PropertyPOJO();
        populate(pojo, params);
        if (params.containsKey("new_posterPath") && params.containsKey("new_posterPathSize")) {
            String newPosterPath = params.get("new_posterPath");
            int newPosterPathSize = new Integer(params.get("new_posterPathSize"));
            if (newPosterPathSize > 0) {
                pojo.setPosterPath(newPosterPath);
                pojo.setPosterPathSize(newPosterPathSize);
            }
        }
        propAction.setBean(pojo);
        if (ADD.equals(action)) {
            propAction.insertRow();
            id = pojo.getIdString();
            action = MODIFY.toString();
        } else if (MODIFY.equals(action)) {
            propAction.updateRow();
        }
        session.setAttribute(propAction.getMessageType(), bundle.getString(propAction.getMessage()));
        uri += "admin/properties.jsp";
//        uri += "?action=" + action + "&id=" + id;
        uri = response.encodeRedirectURL(uri);
        response.sendRedirect(uri);
        out.flush();
        out.close();
    }

    private void populate(IsBean bean, HashMap<String, String> params) {
        PropertyPOJO pojo = CommonUtil.getPropertyPOJO(bean);
        pojo.setIdString(params.get("id"));
        pojo.setPosterPath(params.get("posterPath"));
        pojo.setDoorNumber(params.get("doorNumber"));
        pojo.setStreetAddress(params.get("streetAddress"));
        pojo.setPostalCode(params.get("postalCode"));
        
        
//        cityAction.loadBeanByPostalCode(pojo.getPostalCode());
//        CityPOJO cityPojo = cityAction.getBean();
//        if(cityPojo != null) {
//            pojo.setLatitude(cityPojo.getLatitude());
//            pojo.setLongitude(cityPojo.getLongitude());
//        }
        
        
        pojo.setPropertyType(params.get("propertyType"));
        pojo.setFurniture(params.get("furniture"));
        pojo.setContactName(params.get("contactName"));
        pojo.setContactNumber(params.get("contactNumber"));
        pojo.setRentString(params.get("rent"));
        pojo.setNoOfBedRoomsString(params.get("noOfBedRooms"));
        
        pojo.setLatitude(params.get("latitude"));
        pojo.setLongitude(params.get("longitude"));
//        pojo.setAddressLine1(params.get("addressLine1"));
//        pojo.setAddressLine2(params.get("addressLine2"));
        pojo.setSocietyName(params.get("societyName"));
//        pojo.setAreaName(params.get("areaName"));
        pojo.setCity(params.get("city"));
        pojo.setState(params.get("state"));
        pojo.setCountry(params.get("country"));
        
        pojo.setActive(true);
    }
}
