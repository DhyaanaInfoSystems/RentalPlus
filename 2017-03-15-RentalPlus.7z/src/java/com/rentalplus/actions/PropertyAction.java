/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.actions;

import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import static com.rentalplus.common.Constant.ERROR;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.common.IsBean;
import com.rentalplus.dao.PropertyDAO;
import com.rentalplus.pojo.PropertyPOJO;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Riddhi
 */
public class PropertyAction extends AbstractAction {

    public PropertyAction() {
        super();
        dao = new PropertyDAO();
    }

    public void insertRow() {
        clear();
        messageType = ERROR;
        message = "saveFailed";
        comObj.setBean(getBean());
        dao.insertRow(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            sout(comObj.getIntParam());
            messageType = SUCCESS;
            message = "saveSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    public void removeRows(String ids) {
        clear();
        messageType = ERROR;
        message = "deleteFailed";
        List<Integer> list = new ArrayList<Integer>();
        String[] arr = ids.split(",");
        for (String ele : arr) {
            list.add(new Integer(ele));
        }
        sout(list);
        comObj.setListParam(list);
        dao.softRemoveRows(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            messageType = SUCCESS;
            message = "deleteSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    public void updateRow() {
        clear();
        messageType = ERROR;
        message = "saveFailed";
        comObj.setBean(getBean());
        dao.updateRow(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            sout(comObj.getIntParam());
            messageType = SUCCESS;
            message = "saveSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    public IsBean getLoadedBean() {
        clear();
        comObj.setIntParam(bean.getId());
        dao.getRowById(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            setBean((PropertyPOJO) comObj.getBean());
        } else {
            serr(comObj.getException());
        }
        return getBean();
    }

    public List<PropertyPOJO> getRows() {
        clear();
        List<PropertyPOJO> rows = new ArrayList<PropertyPOJO>();
        dao.getRows(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            if (comObj.getIntParam() > 0) {
                rows.addAll((List<PropertyPOJO>) comObj.getListParam());
            }
        } else {
            serr(comObj.getException());
        }
        return rows;
    }

    public List<PropertyPOJO> getRowsByBean() {
        clear();
        List<PropertyPOJO> rows = new ArrayList<PropertyPOJO>();
        comObj.setBean(bean);
        ((PropertyDAO)dao).getRowsByBean(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            if (comObj.getIntParam() > 0) {
                rows.addAll((List<PropertyPOJO>) comObj.getListParam());
            }
        } else {
            serr(comObj.getException());
        }
        return rows;
    }

    @Override
    public void setBean(IsBean pojo) {
        if(pojo instanceof PropertyPOJO) {
            this.bean = pojo;
        }
    }

    @Override
    public IsBean getBean() {
        return CommonUtil.getPropertyPOJO(bean);
    }
}