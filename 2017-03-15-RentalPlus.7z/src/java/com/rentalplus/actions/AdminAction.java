/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.actions;

import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.Constant.ERROR;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.common.IsBean;
import com.rentalplus.dao.AdminDAO;
import com.rentalplus.pojo.AdminPOJO;

/**
 *
 * @author Riddhi
 */
public class AdminAction extends AbstractAction {

    public AdminAction() {
        super();
        dao = new AdminDAO();
    }

    public void verify() {
        comObj.clear();
        comObj.setBean(bean);
        messageType = ERROR;
        message = "verifyFailed";
        ((AdminDAO) dao).verify(comObj);
        if (SUCCESS.equals(comObj.getStatus()) && comObj.getLongParam() > 0) {
            messageType = SUCCESS;
            message = "verifySuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    @Override
    public void setBean(IsBean pojo) {
        if(pojo instanceof AdminPOJO) {
            this.bean = pojo;
        }
    }

    @Override
    public AdminPOJO getBean() {
        return CommonUtil.getAdminPOJO(bean);
    }
}
