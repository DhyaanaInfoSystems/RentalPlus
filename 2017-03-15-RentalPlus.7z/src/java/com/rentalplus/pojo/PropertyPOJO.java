/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.pojo;

import com.rentalplus.common.IsBean;

/**
 *
 * @author Riddhi
 */
public class PropertyPOJO extends AbstractPOJO implements IsBean {

    private String doorNumber;
    private String streetAddress;
    private String postalCode;
    private String latitude;
    private String longitude;
    private String posterPath;
    private String contactName;
    private String contactNumber;
    private double rent;
    private String propertyType;
    private int noOfBedRooms;
    private String furniture;
    private int posterPathSize;
    private String transportationType;
    private double minRent;
    private double maxRent;
    private String myLocationLatitude;
    private String myLocationLongitude;
    private int minMinutes;
    private int maxMinutes;
    private String addressLine1;
    private String addressLine2;
    private String societyName;
    private String areaName;
    private String city;
    private String state;
    private String country;
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getAddressLine1() {
        StringBuilder sb = new StringBuilder();
        if (doorNumber != null && !doorNumber.isEmpty()) {
            sb.append(doorNumber);
        }
        if (societyName != null && !societyName.isEmpty()) {
            sb.append(", ").append(societyName);
        }
        if (streetAddress != null && !streetAddress.isEmpty()) {
            sb.append(", ").append(streetAddress);
        }
        return sb.toString();
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        StringBuilder sb = new StringBuilder();
        if (areaName != null && !areaName.isEmpty()) {
            sb.append(areaName);
        }
        if (city != null && !city.isEmpty()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(city);
        }
        if (state != null && !state.isEmpty()) {
            sb.append(", ").append(state);
        }
        if (country != null && !country.isEmpty()) {
            sb.append(", ").append(country);
        }
        return sb.toString();
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getSocietyName() {
        return societyName;
    }

    public void setSocietyName(String societyName) {
        this.societyName = societyName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getMinMinutes() {
        return minMinutes;
    }

    public void setMinMinutes(int minMinutes) {
        this.minMinutes = minMinutes;
    }

    public int getMaxMinutes() {
        return maxMinutes;
    }

    public void setMaxMinutes(int maxMinutes) {
        this.maxMinutes = maxMinutes;
    }

    public void setMinMinutesString(String minMinutes) {
        this.minMinutes = new Integer(minMinutes);
    }

    public void setMaxMinutesString(String maxMinutes) {
        this.maxMinutes = new Integer(maxMinutes);
    }

    public String getAddress() {
        return (doorNumber + "," + streetAddress);
    }

    public String getTransportationType() {
        return transportationType;
    }

    public void setTransportationType(String transportationType) {
        this.transportationType = transportationType;
    }

    public double getMinRent() {
        return minRent;
    }

    public void setMinRent(double minRent) {
        this.minRent = minRent;
    }

    public void setMinRentString(String minRent) {
        this.minRent = new Double(minRent);
    }

    public void setMaxRentString(String maxRent) {
        this.maxRent = new Double(maxRent);
    }

    public double getMaxRent() {
        return maxRent;
    }

    public void setMaxRent(double maxRent) {
        this.maxRent = maxRent;
    }

    public String getMyLocationLatitude() {
        return myLocationLatitude;
    }

    public void setMyLocationLatitude(String myLocationLatitude) {
        this.myLocationLatitude = myLocationLatitude;
    }

    public String getMyLocationLongitude() {
        return myLocationLongitude;
    }

    public void setMyLocationLongitude(String myLocationLongitude) {
        this.myLocationLongitude = myLocationLongitude;
    }

    public int getPosterPathSize() {
        return posterPathSize;
    }

    public void setPosterPathSize(int posterPathSize) {
        this.posterPathSize = posterPathSize;
    }

    public void setPosterPathSizeString(String posterPathSize) {
        this.posterPathSize = new Integer(posterPathSize);
    }

    public String getDoorNumber() {
        return doorNumber;
    }

    public void setDoorNumber(String doorNumber) {
        this.doorNumber = doorNumber;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public void setRentString(String rent) {
        this.rent = new Double(rent);
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType == null ? "" : propertyType;
    }

    public int getNoOfBedRooms() {
        return noOfBedRooms;
    }

    public void setNoOfBedRooms(int noOfBedRooms) {
        this.noOfBedRooms = noOfBedRooms;
    }

    public void setNoOfBedRoomsString(String noOfBedRooms) {
        this.noOfBedRooms = new Integer(noOfBedRooms);
    }

    public String getFurniture() {
        return furniture == null ? "" : furniture;
    }

    public void setFurniture(String furniture) {
        this.furniture = furniture;
    }

    @Override
    public String toString() {
        return (super.toString() + " " + getDoorNumber() + " " + getStreetAddress());
    }

}
