/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.dao;

import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import com.rentalplus.common.CommunicationObject;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.pojo.PropertyPOJO;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Riddhi
 */
public class PropertyDAO extends AbstractDAO {

    @Override
    public CommunicationObject getRows(CommunicationObject request) {
        request.setPojoClass(PropertyPOJO.class);
        request.setBooleanParam(true);
        return super.getRows(request);
    }

    @Override
    public CommunicationObject getRowById(CommunicationObject request) {
        request.setPojoClass(PropertyPOJO.class);
        return super.getRowById(request);
    }

    public static void main(String[] args) {
        try {
            PropertyDAO dao = new PropertyDAO();
            CommunicationObject request = new CommunicationObject();
            dao.getRows(request);
            if (SUCCESS.equals(request.getStatus())) {
                List<PropertyPOJO> rows = (List<PropertyPOJO>) request.getListParam();
                for (PropertyPOJO row : rows) {
                    sout(row);
                    if (row.getId() == 3) {
                        row.setDoorNumber("23 BhumiKurpa Society");
                        row.setRent(15555);
                        CommunicationObject request2 = new CommunicationObject();
                        request2.setBean(row);
                        dao.updateRow(request2);
                        if (SUCCESS.equals(request2.getStatus())) {
                            sout("Record updated successfully");
                        }
                    }
                }
            } else {
                serr(request.getException());
            }
        } finally {
            AdminDAO.disconnect();
        }
    }

    @Override
    public CommunicationObject softRemoveRows(CommunicationObject request) {
        request.setStringParam("PropertyPOJO");
        return super.softRemoveRows(request);
    }

    public CommunicationObject getRowsByBean(CommunicationObject request) {
        try {
            if (request.getBean() != null) {
                PropertyPOJO pojo = CommonUtil.getPropertyPOJO(request.getBean());
                startOperation();
                Criteria criteria = getSession().createCriteria(PropertyPOJO.class);
                criteria.add(Restrictions.eq("active", true));

                if (pojo.getPropertyType() != null && !pojo.getPropertyType().isEmpty()) {
                    criteria.add(Restrictions.like("propertyType", pojo.getPropertyType()));
                }
                if (pojo.getFurniture() != null && !pojo.getFurniture().isEmpty()) {
                    criteria.add(Restrictions.like("furniture", pojo.getFurniture()));
                }
                if (pojo.getNoOfBedRooms() > 0) {
                    criteria.add(Restrictions.ge("noOfBedRooms", pojo.getNoOfBedRooms()));
                }
                if (pojo.getMinRent() > 0 && pojo.getMaxRent() > pojo.getMinRent()) {
                    criteria.add(Restrictions.between("rent", pojo.getMinRent(), pojo.getMaxRent()));
                } else if (pojo.getMaxRent() > 0 && pojo.getMinRent() == 0) {
                    criteria.add(Restrictions.le("rent", pojo.getMaxRent()));
                } else if (pojo.getMinRent() > 0 && pojo.getMaxRent() == 0) {
                    criteria.add(Restrictions.ge("rent", pojo.getMinRent()));
                }
                List rows = criteria.list();
                endOperation();
                request.setListParam(rows);
                request.setIntParam(rows.size());
                request.setStatus(SUCCESS);
            } else {
                request.setStatus(WARNING);
                request.setStringParam("Bean not found");
            }
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }
}
