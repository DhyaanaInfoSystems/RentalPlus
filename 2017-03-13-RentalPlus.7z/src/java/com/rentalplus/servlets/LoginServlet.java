package com.rentalplus.servlets;

import com.rentalplus.actions.AdminAction;
import static com.rentalplus.common.Constant.LOGGED_IN_USER;
import static com.rentalplus.common.Constant.LOGOUT_USER;
import static com.rentalplus.common.Constant.SIGNIN;
import static com.rentalplus.common.Constant.SIGNOUT;
import static com.rentalplus.common.Constant.SUCCESS;
import com.rentalplus.pojo.AdminPOJO;
import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends BaseServlet {

    private AdminAction adminAction;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        adminAction = new AdminAction();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        super.doGet(request, response);
        String uri = getServletContext().getInitParameter("base");
        if (SIGNOUT.equals(action)) {
            /*Cookie[] cookies = request.getCookies();
             if (cookies != null) {
             for (Cookie c : cookies) {
             if (LOGGED_IN_USER.equals(c.getName())) {
             c.setMaxAge(0);
             response.addCookie(c);
             break;
             }
             }
             }*/
            session.removeAttribute(LOGGED_IN_USER.toString());
        }
        session.setAttribute(SUCCESS.toString(), bundle.getString(LOGOUT_USER.toString()));
        uri += "login.jsp";
        uri = response.encodeRedirectURL(uri);
        response.sendRedirect(uri);
        out.flush();
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        super.doPost(request, response);
        String uri = getServletContext().getInitParameter("base");
        if (SIGNIN.equals(action)) {
            AdminPOJO pojo = new AdminPOJO();
            pojo.setEmail(request.getParameter("email"));
            pojo.setPassword(request.getParameter("password"));
            adminAction.setBean(pojo);
            adminAction.verify();
            if (SUCCESS.equals(adminAction.getMessageType())) {
                /*Cookie cookie = new Cookie(LOGGED_IN_USER.toString(), pojo.getEmail());
                 cookie.setMaxAge(MONTH);
                 response.addCookie(cookie);*/
                session.setAttribute(LOGGED_IN_USER.toString(), pojo.getEmail());
                uri += "properties.jsp";
            } else {
                session.setAttribute(adminAction.getMessageType(), bundle.getString(adminAction.getMessage()));
                uri += "login.jsp";
            }
        }
        uri = response.encodeRedirectURL(uri);
        response.sendRedirect(uri);
        out.flush();
        out.close();
    }
}
