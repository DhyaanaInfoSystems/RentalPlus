package com.rentalplus.dao;

import com.rentalplus.common.CommunicationObject;
import static com.rentalplus.common.Constant.ERROR;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.common.IsBean;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class AbstractDAO {

    private static Configuration configuration;
    private static SessionFactory sessionFactory;
    private Session session;
    private Transaction transaction;

    public AbstractDAO() {

    }

    public static void configure() {
        if (configuration == null) {
            configuration = new Configuration();
            configuration.configure("hibernate.cfg.xml");
            sessionFactory = configuration.buildSessionFactory();
        }
    }

    public static void disconnect() {
        if (sessionFactory != null) {
            sessionFactory.close();
            configuration = null;
            sessionFactory = null;
        }
    }

    public static Configuration getConfiguration() {
        return configuration;
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public Session getSession() {
        return session;
    }

    public void startOperation() {
        configure();
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
    }

    public void startReadOperation() {
        configure();
        session = sessionFactory.openSession();
    }

    public void endOperation() {
        if (session != null && transaction != null) {
            transaction.commit();
            session.close();
        }
    }

    public void endReadOperation() {
        if (session != null) {
            session.close();
        }
    }

    public void handle(Exception ex, CommunicationObject request) {
        ex.printStackTrace(System.err);
        if (request != null) {
            request.setException(ex);
            request.setStatus(ERROR);
        }
    }

    public CommunicationObject insertRow(CommunicationObject request) {
        try {
            if (request.getBean() != null) {
                startOperation();
                Integer insertedId = (Integer) getSession().save(request.getBean());
                request.setIntParam(insertedId);
                endOperation();
                request.setStatus(SUCCESS);
            } else {
                request.setStringParam("Bean Not Found");
                request.setStatus(WARNING);
            }
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }

    public CommunicationObject updateRow(CommunicationObject request) {
        try {
            if (request.getBean() != null) {
                startOperation();
                getSession().update(request.getBean());
                endOperation();
                request.setStatus(SUCCESS);
            } else {
                request.setStringParam("Bean Not Found");
                request.setStatus(WARNING);
            }
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }

    public CommunicationObject getRows(CommunicationObject request) {
        try {
            startOperation();
            Criteria criteria = getSession().createCriteria(request.getPojoClass());
            criteria.add(Restrictions.eq("active", request.isBooleanParam()));
            List rows = criteria.list();
            endOperation();
            request.setListParam(rows);
            request.setIntParam(rows.size());
            request.setStatus(SUCCESS);
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }

    public CommunicationObject getRowById(CommunicationObject request) {
        try {
            startOperation();
            IsBean bean = (IsBean) getSession().get(request.getPojoClass(), request.getIntParam());
            request.setBean(bean);
            endOperation();
            request.setStatus(SUCCESS);
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }

    public CommunicationObject softRemoveRows(CommunicationObject request) {
        try {
            startOperation();
            String hql = "UPDATE " + request.getStringParam() + " _table SET _table.active = :active WHERE _table.id IN (:idList)";
            Query query = getSession().createQuery(hql);
            query.setParameter("active", false);
            query.setParameterList("idList", request.getListParam());
            int rowsAffected = query.executeUpdate();
            endOperation();
            request.setIntParam(rowsAffected);
            request.setStatus(SUCCESS);
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }
}
