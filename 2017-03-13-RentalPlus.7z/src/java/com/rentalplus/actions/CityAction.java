/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.actions;

import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.Constant.ERROR;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.common.IsBean;
import com.rentalplus.dao.CityDAO;
import com.rentalplus.pojo.CityPOJO;

/**
 *
 * @author Devang
 */
public class CityAction extends AbstractAction {

    public CityAction() {
        super();
        dao = new CityDAO();
    }

    @Override
    public void setBean(IsBean pojo) {
        if (pojo instanceof CityPOJO) {
            this.bean = pojo;
        }
    }

    public void loadBeanByPostalCode(String postalCode) {
        clear();
        comObj.setStringParam(postalCode);
        messageType = ERROR;
        message = "findFailed";
        ((CityDAO) dao).getRowByPostalCode(comObj);
        if (SUCCESS.equals(comObj.getStatus()) && comObj.getBean() != null) {
            setBean((CityPOJO) comObj.getBean());
            messageType = SUCCESS;
            message = "findSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    @Override
    public CityPOJO getBean() {
        return CommonUtil.getCityPOJO(bean);
    }
}
