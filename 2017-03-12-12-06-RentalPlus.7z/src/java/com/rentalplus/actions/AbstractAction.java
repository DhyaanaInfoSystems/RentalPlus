/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.actions;

import com.rentalplus.common.CommunicationObject;
import com.rentalplus.common.Constant;
import static com.rentalplus.common.Constant.UNKNOWN;
import com.rentalplus.common.IsBean;
import com.rentalplus.dao.AbstractDAO;

/**
 *
 * @author Devang
 */
public abstract class AbstractAction {

    protected CommunicationObject comObj;
    protected String message;
    protected Constant messageType;
    protected AbstractDAO dao;
    protected IsBean bean;

    public AbstractAction() {
        comObj = new CommunicationObject();
        clear();
    }

    public final void clear() {
        comObj.clear();
        message = "";
        messageType = UNKNOWN;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageType() {
        return messageType.toString();
    }

    public abstract IsBean getBean();

    public abstract void setBean(IsBean pojo);

}
