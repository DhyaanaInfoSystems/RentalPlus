package com.rentalplus.dao;

import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import com.rentalplus.common.CommunicationObject;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.common.IsBean;
import com.rentalplus.pojo.CityPOJO;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Devang
 */
public class CityDAO extends AbstractDAO {

    @Override
    public CommunicationObject getRows(CommunicationObject request) {
        request.setPojoClass(CityPOJO.class);
        request.setBooleanParam(true);
        return super.getRows(request);
    }

    public static void main(String[] args) {
        try {
            CityDAO dao = new CityDAO();
            CommunicationObject request = new CommunicationObject();
            dao.getRows(request);
            if (SUCCESS.equals(request.getStatus())) {
                List<CityPOJO> rows = (List<CityPOJO>) request.getListParam();
                for (CityPOJO row : rows) {
                    sout(row);
                }
            } else {
                serr(request.getException());
            }
        } finally {
            AdminDAO.disconnect();
        }
    }

    public CommunicationObject getRowByPostalCode(CommunicationObject request) {
        try {
            if (request.getStringParam() != null && !request.getStringParam().isEmpty()) {
                startOperation();
                Criteria criteria = getSession().createCriteria(CityPOJO.class);
                criteria.add(Restrictions.eq("postalCode", request.getStringParam()));
                criteria.setMaxResults(1);
                criteria.addOrder(Order.asc("id"));
                IsBean bean = (IsBean) criteria.uniqueResult();
                endOperation();
                if (bean.getId() > 0) {
                    request.setBean(bean);
                    request.setStatus(SUCCESS);
                } else {
                    request.setStatus(WARNING);
                    request.setStringParam("Postal code not found");
                }
            } else {
                request.setStatus(WARNING);
                request.setStringParam("String parameter not found");
            }
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }
}
