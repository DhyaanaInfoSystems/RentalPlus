package com.rentalplus.dao;

import com.rentalplus.common.CommonUtil;
import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import com.rentalplus.common.CommunicationObject;
import static com.rentalplus.common.Constant.SUCCESS;
import com.rentalplus.pojo.AdminPOJO;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Devang
 */
public class AdminDAO extends AbstractDAO {

    public CommunicationObject verify(CommunicationObject request) {
        try {
            if (request.getBean() != null && request.getBean() instanceof AdminPOJO) {
                AdminPOJO pojo = CommonUtil.getAdminPOJO(request.getBean());
                startOperation();
                Criteria criteria = getSession().createCriteria(AdminPOJO.class);
                criteria.add(Restrictions.eq("email", pojo.getEmail()));
                criteria.add(Restrictions.eq("password", pojo.getPassword()));
                criteria.add(Restrictions.eq("active", true));
                criteria.setProjection(Projections.count("id"));
                Long countRows = (Long) criteria.uniqueResult();
                endOperation();
                request.setStatus(SUCCESS);
                request.setLongParam(countRows);
            } else {
                throw new RuntimeException("AdminPOJO not found");
            }
        } catch (HibernateException ex) {
            handle(ex, request);
        }
        return request;
    }

    @Override
    public CommunicationObject getRows(CommunicationObject request) {
        request.setPojoClass(AdminPOJO.class);
        request.setBooleanParam(true);
        return super.getRows(request);
    }

    public static void main(String[] args) {
        try {
            AdminDAO dao = new AdminDAO();
            CommunicationObject request = new CommunicationObject();
            dao.getRows(request);
            if (SUCCESS.equals(request.getStatus())) {
                List<AdminPOJO> rows = (List<AdminPOJO>) request.getListParam();
                for (AdminPOJO row : rows) {
                    sout(row);
                }
            } else {
                serr(request.getException());
            }
        } finally {
            AdminDAO.disconnect();
        }
    }
}