package com.rentalplus.common;

import com.google.gson.Gson;
import com.rentalplus.pojo.AdminPOJO;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

public abstract class CommonUtil {

    public static final int DAY = 24 * 60 * 60;
    public static final int MONTH = 30 * DAY;
    private static final Gson gson = new Gson();

    public static Gson getGson() {
        return gson;
    }

    public static void sout(Object str) {
        System.out.println("INF: " + str);
    }

    public static void serr(Object str) {
        System.err.println("ERR: " + str);
    }

    public static AdminPOJO getAdminPOJO(IsBean bean) {
        return (AdminPOJO) bean;
    }

    public static String uploadFile(FileItem fi, String relativePath, String actualPath) throws Exception {
        // Get the uploaded file parameters
        String fileName = fi.getName();
        String fieldName = fi.getFieldName();
        String contentType = fi.getContentType();
        boolean isInMemory = fi.isInMemory();
        long sizeInBytes = fi.getSize();
        if (sizeInBytes > 0) {
            // Write the file
            File file;
            if (fileName.lastIndexOf("\\") >= 0) {
                file = new File(actualPath, fileName.substring(fileName.lastIndexOf("\\")));
            } else {
                file = new File(actualPath, fileName.substring(fileName.lastIndexOf("\\") + 1));
            }
            fi.write(file);
            return relativePath.substring(1)+fileName;
        } else {
            return "home-default.png";
        }
    }

    public static HashMap<String, String> getParametersFromMultipartContentRequest(HttpServletRequest request) {
        HashMap<String, String> params = new HashMap<String, String>();
        String filePath = request.getServletContext().getInitParameter("file-upload");
        String realPath = request.getServletContext().getRealPath(filePath);
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // maximum size that will be stored in memory
        // factory.setSizeThreshold(maxMemSize);
        // Location to save data that is larger than maxMemSize.
        // factory.setRepository(new File("c:\\temp"));

        // Create a new file upload handler
        ServletFileUpload upload = new ServletFileUpload(factory);
        // maximum file size to be uploaded.
        // upload.setSizeMax(maxFileSize);

        try {
            // Parse the request to get file items.
            Map<String, List<FileItem>> parameterMap = upload.parseParameterMap(request);
            for (String key : parameterMap.keySet()) {
                // out.println(key);
                List<FileItem> fileItems = parameterMap.get(key);
                // out.println(fileItems);
                // Process the uploaded file items
                
                String value = "";
                for (FileItem fi: fileItems) {
                    if (!fi.isFormField()) {
                        value = uploadFile(fi, filePath, realPath);
                    } else {
                        value = fi.getString();
                    }
                    if(params.containsKey(key)) {
                        params.put(key, params.get(key)+","+value);
                    } else {
                        params.put(key, value);
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return params;
    }
}
