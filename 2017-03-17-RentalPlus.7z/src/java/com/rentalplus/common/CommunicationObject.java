package com.rentalplus.common;

import java.util.HashMap;
import java.util.List;

public class CommunicationObject {
    private int intParam;
    private long longParam;
    private boolean booleanParam;
    private double doubleParam;
    private String stringParam;
    private List<String> stringListParam;
    private List<Long> longListParam;
    private List<? extends  Object> listParam;
    private HashMap<String, Object> mapParam;
    private HashMap<Constant, Object> mapParam2;
    private IsBean bean;
    private Exception exception;
    private Constant status;
    private Class pojoClass;

    public void clear() {
        doubleParam = longParam = intParam = 0;
        booleanParam = false;
        stringParam = null;
        stringListParam = null;
        longListParam = null;
        listParam = null;
        mapParam = null;
        mapParam2 = null;
        bean = null;
        exception = null;
        status = null;
        pojoClass = null;
    }
    
    public Class getPojoClass() {
        return pojoClass;
    }

    public void setPojoClass(Class pojoClass) {
        this.pojoClass = pojoClass;
    }

    public HashMap<Constant, Object> getMapParam2() {
        return mapParam2;
    }

    public void setMapParam2(HashMap<Constant, Object> mapParam2) {
        this.mapParam2 = mapParam2;
    }

    public Constant getStatus() {
        return status;
    }

    public void setStatus(Constant status) {
        this.status = status;
    }

    public List<Long> getLongListParam() {
        return longListParam;
    }

    public void setLongListParam(List<Long> longListParam) {
        this.longListParam = longListParam;
    }

    public List<? extends  Object> getListParam() {
        return listParam;
    }

    public void setListParam(List<? extends Object> listParam) {
        this.listParam = listParam;
    }

    public Exception getException() {
        return exception;
    }

    public void setException(Exception exception) {
        this.exception = exception;
    }
    
    public IsBean getBean() {
        return bean;
    }

    public void setBean(IsBean bean) {
        this.bean = bean;
    }

    public int getIntParam() {
        return intParam;
    }

    public void setIntParam(int intParam) {
        this.intParam = intParam;
    }

    public long getLongParam() {
        return longParam;
    }

    public void setLongParam(long longParam) {
        this.longParam = longParam;
    }

    public boolean isBooleanParam() {
        return booleanParam;
    }

    public void setBooleanParam(boolean booleanParam) {
        this.booleanParam = booleanParam;
    }

    public double getDoubleParam() {
        return doubleParam;
    }

    public void setDoubleParam(double doubleParam) {
        this.doubleParam = doubleParam;
    }

    public String getStringParam() {
        return stringParam;
    }

    public void setStringParam(String stringParam) {
        this.stringParam = stringParam;
    }

    public List<String> getStringListParam() {
        return stringListParam;
    }

    public void setStringListParam(List<String> stringListParam) {
        this.stringListParam = stringListParam;
    }

    public HashMap<String, Object> getMapParam() {
        return mapParam;
    }

    public void setMapParam(HashMap<String, Object> mapParam) {
        this.mapParam = mapParam;
    }
}
