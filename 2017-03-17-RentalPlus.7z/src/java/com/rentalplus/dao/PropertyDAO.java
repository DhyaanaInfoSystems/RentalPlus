/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.dao;

import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import com.rentalplus.common.CommunicationObject;
import static com.rentalplus.common.Constant.SUCCESS;
import com.rentalplus.pojo.PropertyPOJO;
import java.util.List;

/**
 *
 * @author Devang
 */
public class PropertyDAO extends AbstractDAO {

    @Override
    public CommunicationObject getRows(CommunicationObject request) {
        request.setPojoClass(PropertyPOJO.class);
        request.setBooleanParam(true);
        return super.getRows(request);
    }

    @Override
    public CommunicationObject getRowById(CommunicationObject request) {
        request.setPojoClass(PropertyPOJO.class);
        return super.getRowById(request); 
    }

    public static void main(String[] args) {
        try {
            PropertyDAO dao = new PropertyDAO();
            CommunicationObject request = new CommunicationObject();
            dao.getRows(request);
            if (SUCCESS.equals(request.getStatus())) {
                List<PropertyPOJO> rows = (List<PropertyPOJO>) request.getListParam();
                for (PropertyPOJO row : rows) {
                    sout(row);
                }
            } else {
                serr(request.getException());
            }
        } finally {
            AdminDAO.disconnect();
        }
    }
}
