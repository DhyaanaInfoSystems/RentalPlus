/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.servlets;

import com.rentalplus.actions.PropertyAction;
import static com.rentalplus.common.CommonUtil.getParametersFromMultipartContentRequest;
import static com.rentalplus.common.Constant.ADD;
import static com.rentalplus.common.Constant.MODIFY;
import com.rentalplus.pojo.PropertyPOJO;
import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author Devang
 */
public class PropServlet extends BaseServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        super.doGet(request, response);
        String requestUri = request.getRequestURI();
        // out.println(requestUri);
        String[] pathElements = requestUri.split("/");
//        out.print(Arrays.toString(pathElements));
        String base = pathElements[1];
        String actionHandler = pathElements[2];
        String action = pathElements[3];
        String id = "0";
        if (pathElements.length > 4) {
            id = pathElements[4];
        }
        String uri = getServletContext().getInitParameter("base") + "property.jsp";
        uri += "?action=" + action + "&id=" + id;
        uri = response.encodeRedirectURL(uri);
//        out.print(uri);
        response.sendRedirect(uri);

//        request.setAttribute("action", action);
//        request.setAttribute("id", id);
//        dispatcher = request.getRequestDispatcher(uri);
//        dispatcher.forward(request, response);
        out.flush();
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        super.doPost(request, response);
        String requestUri = request.getRequestURI();
        // out.println(requestUri);
        String[] pathElements = requestUri.split("/");
//        out.print(Arrays.toString(pathElements));
        String base = pathElements[1];
        String actionHandler = pathElements[2];
        String action = pathElements[3];
        String id = "0";
        if (pathElements.length > 4) {
            id = pathElements[4];
        }
        HashMap<String, String> params;
        if (ServletFileUpload.isMultipartContent(request)) {
            params = getParametersFromMultipartContentRequest(request);
        } else {
            params = new HashMap<String, String>();
            Enumeration<String> en = request.getParameterNames();
            while (en.hasMoreElements()) {
                String pkey = en.nextElement();
                String pval;
                String[] values = request.getParameterValues(pkey);
                if (values == null || values.length < 2) {
                    pval = values[0];
                } else {
                    pval = Arrays.toString(values);
                }
                params.put(pkey, pval);
            }
        }
        PropertyPOJO pojo = new PropertyPOJO();
        pojo.setPosterPath(params.get("posterPath"));
        pojo.setDoorNumber(params.get("doorNumber"));
        pojo.setStreetAddress(params.get("streetAddress"));
        pojo.setPostalCode(params.get("postalCode"));
        pojo.setPropertyType(params.get("propertyType"));
        pojo.setFurniture(params.get("furniture"));
        pojo.setContactName(params.get("contactName"));
        pojo.setContactNumber(params.get("contactNumber"));
        pojo.setRentString(params.get("rent"));
        pojo.setNoOfBedRoomsString(params.get("noOfBedRooms"));
        pojo.setActive(true);
        PropertyAction propAction = new PropertyAction();
        propAction.setBean(pojo);
        if (ADD.equals(action)) {
            propAction.insertRow();
            id = pojo.getIdString();
            action = MODIFY.toString();
        } else if(MODIFY.equals(action)) {
            propAction.updateRow();
        }
        session.setAttribute(propAction.getMessageType(), bundle.getString(propAction.getMessage()));

        String uri = getServletContext().getInitParameter("base") + "property.jsp";
        uri += "?action=" + action + "&id=" + id;
        uri = response.encodeRedirectURL(uri);
//        out.print(uri);
        response.sendRedirect(uri);
        out.flush();
        out.close();
    }
}
