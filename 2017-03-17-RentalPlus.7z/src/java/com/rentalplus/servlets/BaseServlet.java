package com.rentalplus.servlets;

import com.google.gson.Gson;
import static com.rentalplus.common.CommonUtil.getGson;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BaseServlet extends HttpServlet {

    protected OutputStream outputStream;
    protected PrintWriter out;
    protected HttpSession session;
    protected Locale locale;
    protected ResourceBundle bundle;
    protected Gson gson;
    protected RequestDispatcher dispatcher;

    private void initialize(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");

        String encodings = request.getHeader("Accept-Encoding");
        if (encodings != null && encodings.contains("gzip")) {
            response.setHeader("Content-Encoding", "gzip");
            outputStream = new GZIPOutputStream(response.getOutputStream());
        } else if (encodings != null && encodings.contains("compress")) {
            response.setHeader("Content-Encoding", "x-compress");
            outputStream = new ZipOutputStream(response.getOutputStream());
            ((ZipOutputStream) outputStream).putNextEntry(new ZipEntry("dummy name"));
        } else {
            outputStream = response.getOutputStream();
        }
        response.setHeader("Vary", "Accept-Encoding");
        out = new PrintWriter(outputStream);
        session = request.getSession(true);
        locale = request.getLocale();
        bundle = ResourceBundle.getBundle("com.rentalplus.common.Dictionary", locale);
        gson = getGson();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        initialize(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        initialize(request, response);
    }

}
