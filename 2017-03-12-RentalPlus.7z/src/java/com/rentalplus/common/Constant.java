/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.common;

/**
 *
 * @author Devang
 */
public enum Constant {

    SUCCESS, ERROR, INFO, WARNING, VERIFIED, NO_ACTION, TRUE, FALSE,
    LOGGED_IN_USER, LOGOUT_USER, JSON_REQUEST, ADD, MODIFY, REMOVE, UNKNOWN, VERIFY, SIGNIN, SIGNOUT;

    public boolean equals(String value) {
        return (this.toString().equals(value));
    }
    
    @Override
    public String toString() {
        switch (this) {
            case SUCCESS:
                return "success";
            case ERROR:
                return "error";
            case WARNING:
                return "warning";
            case INFO:
                return "info";
            case VERIFIED:
                return "verified";
            case LOGGED_IN_USER:
                return "loggedInUser";
            case LOGOUT_USER:
                return "signOutSuccess";
            case JSON_REQUEST:
                return "jsonReq";
            case NO_ACTION:
                return "Action not found";
            case TRUE:
                return "true";
            case FALSE:
                return "false";
            case ADD:
                return "add";
            case REMOVE:
                return "remove";
            case MODIFY:
                return "modify";
            case VERIFY:
                return "verify";
            case SIGNIN:
                return "in";
            case SIGNOUT:
                return "out";
            default:
                return null;
        }
    }

    public Constant valueOf(Constant constant, String value) {
        for (Constant c : Constant.values()) {
            if (c.equals(value)) {
                return c;
            }
        }
        return null;
    }
}
