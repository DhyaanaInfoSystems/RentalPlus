/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.pojo;

import com.rentalplus.common.IsBean;

/**
 *
 * @author Devang
 */
public class PropertyPOJO extends AbstractPOJO implements IsBean{
    
    private String doorNumber;
    private String streetAddress;
    private String postalCode;
    private String latitude;
    private String longitude;
    private String posterPath;
    private String contactName;
    private String contactNumber;
    private double rent;
    private String propertyType;
    private int noOfBedRooms;
    private String furniture;
    private int posterPathSize;

    public int getPosterPathSize() {
        return posterPathSize;
    }

    public void setPosterPathSize(int posterPathSize) {
        this.posterPathSize = posterPathSize;
    }
    
    public void setPosterPathSizeString(String posterPathSize) {
        this.posterPathSize = new Integer(posterPathSize);
    }
    
    public String getDoorNumber() {
        return doorNumber;
    }

    public void setDoorNumber(String doorNumber) {
        this.doorNumber = doorNumber;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }
    public void setRentString(String rent) {
        this.rent = new Double(rent);
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public int getNoOfBedRooms() {
        return noOfBedRooms;
    }

    public void setNoOfBedRooms(int noOfBedRooms) {
        this.noOfBedRooms = noOfBedRooms;
    }
    
    public void setNoOfBedRoomsString(String noOfBedRooms) {
        this.noOfBedRooms = new Integer(noOfBedRooms);
    }

    public String getFurniture() {
        return furniture;
    }

    public void setFurniture(String furniture) {
        this.furniture = furniture;
    }
    
    @Override
    public String toString() {
        return (super.toString()+" "+getDoorNumber()+" "+getStreetAddress());
    }
    
}
