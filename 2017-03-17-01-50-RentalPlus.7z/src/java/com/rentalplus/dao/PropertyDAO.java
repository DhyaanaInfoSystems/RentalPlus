/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.dao;

import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import com.rentalplus.common.CommunicationObject;
import static com.rentalplus.common.Constant.SUCCESS;
import com.rentalplus.pojo.PropertyPOJO;
import java.util.List;
import org.hibernate.Query;

/**
 *
 * @author Devang
 */
public class PropertyDAO extends AbstractDAO {

    @Override
    public CommunicationObject getRows(CommunicationObject request) {
        request.setPojoClass(PropertyPOJO.class);
        request.setBooleanParam(true);
        return super.getRows(request);
    }

    @Override
    public CommunicationObject getRowById(CommunicationObject request) {
        request.setPojoClass(PropertyPOJO.class);
        return super.getRowById(request);
    }

    public static void main(String[] args) {
        try {
            PropertyDAO dao = new PropertyDAO();
            CommunicationObject request = new CommunicationObject();
            dao.getRows(request);
            if (SUCCESS.equals(request.getStatus())) {
                List<PropertyPOJO> rows = (List<PropertyPOJO>) request.getListParam();
                for (PropertyPOJO row : rows) {
                    sout(row);
                    if (row.getId() == 3) {
                        row.setDoorNumber("23 BhumiKurpa Society");
                        row.setRent(15555);
                        CommunicationObject request2 = new CommunicationObject();
                        request2.setBean(row);
                        dao.updateRow(request2);
                        if (SUCCESS.equals(request2.getStatus())) {
                            sout("Record updated successfully");
                        }
                    }
                }
            } else {
                serr(request.getException());
            }
        } finally {
            AdminDAO.disconnect();
        }
    }

    @Override
    public CommunicationObject softRemoveRows(CommunicationObject request) {
        request.setStringParam("PropertyPOJO");
        return super.softRemoveRows(request);
    }
}
