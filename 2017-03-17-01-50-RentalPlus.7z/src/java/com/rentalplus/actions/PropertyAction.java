/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rentalplus.actions;

import static com.rentalplus.common.CommonUtil.serr;
import static com.rentalplus.common.CommonUtil.sout;
import com.rentalplus.common.CommunicationObject;
import com.rentalplus.common.Constant;
import static com.rentalplus.common.Constant.ERROR;
import static com.rentalplus.common.Constant.SUCCESS;
import static com.rentalplus.common.Constant.UNKNOWN;
import static com.rentalplus.common.Constant.WARNING;
import com.rentalplus.dao.PropertyDAO;
import com.rentalplus.pojo.PropertyPOJO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Devang
 */
public class PropertyAction {

    private CommunicationObject comObj;
    private PropertyDAO dao;
    private String message;
    private Constant messageType;
    private PropertyPOJO bean;

    public PropertyAction() {
        dao = new PropertyDAO();
        comObj = new CommunicationObject();
        clear();
    }

    public final void clear() {
        comObj.clear();
        message = "";
        messageType = UNKNOWN;
    }

    public void insertRow() {
        clear();
        messageType = ERROR;
        message = "saveFailed";
        comObj.setBean(getBean());
        dao.insertRow(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            sout(comObj.getIntParam());
            messageType = SUCCESS;
            message = "saveSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    public void removeRows(String ids) {
        clear();
        messageType = ERROR;
        message = "deleteFailed";
        List<Integer> list = new ArrayList<Integer>();
        String [] arr = ids.split(",");
        for(String ele: arr) {
            list.add(new Integer(ele));
        }
        sout(list);
        comObj.setListParam(list);
        dao.softRemoveRows(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            messageType = SUCCESS;
            message = "deleteSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    public void updateRow() {
        clear();
        messageType = ERROR;
        message = "saveFailed";
        comObj.setBean(getBean());
        dao.updateRow(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            sout(comObj.getIntParam());
            messageType = SUCCESS;
            message = "saveSuccess";
        } else if (WARNING.equals(comObj.getStatus())) {
            serr(comObj.getStringParam());
        } else {
            serr(comObj.getException());
        }
    }

    public PropertyPOJO getLoadedBean() {
        clear();
        comObj.setIntParam(bean.getId());
        dao.getRowById(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            setBean((PropertyPOJO) comObj.getBean());
        } else {
            serr(comObj.getException());
        }
        return getBean();
    }

    public List<PropertyPOJO> getRows() {
        clear();
        List<PropertyPOJO> rows = new ArrayList<PropertyPOJO>();
        dao.getRows(comObj);
        if (SUCCESS.equals(comObj.getStatus())) {
            if (comObj.getIntParam() > 0) {
                rows.addAll((List<PropertyPOJO>) comObj.getListParam());
            }
        } else {
            serr(comObj.getException());
        }
        return rows;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageType() {
        return messageType.toString();
    }

    public PropertyPOJO getBean() {
        return bean;
    }

    public void setBean(PropertyPOJO pojo) {
        this.bean = pojo;
    }

}
